# EC2 Instance and Auto Scaling Group Setup Flow



